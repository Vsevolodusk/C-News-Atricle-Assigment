﻿namespace NewsPortal.BLL.Interfaces
{
    public interface IModel
    {
        int Id { get; set; }
    }
}
