﻿namespace NewsPortal.DAL.Interfaces
{
    public interface IEntity
    {
    }
}
